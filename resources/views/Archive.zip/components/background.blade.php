<div class="section padding-top-bottom over-hide">
    <div class="container">
        <div class="row">
            <div class="col-md-6 align-self-center">
                <div class="row justify-content-center">
                    <div class="col-10">
                        <div class="subtitle text-center mb-4">Brief History</div>
                        <h2 class="text-center">Background</h2>
                        <p class="text-center mt-5">The Nanji 2010 Company Limited also engaging in the supplies of building construction materials, industrial raw minerals, automobile/automotive spare parts and electrical insulator for transmission and hot line connectors for different applications.</p>

                    </div>
                </div>
            </div>
            <div class="col-md-6 mt-4 mt-md-0">
                <div class="img-wrap">
                    <img src="img/automobiles.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>