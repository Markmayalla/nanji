<div class="section padding-top-bottom over-hide">
    <div class="container">
        <div class="row">


            <div class="col-md-12 align-self-center">
                <div class="row justify-content-center">
                    <div class="col-10">
                        <div class="subtitle text-center mb-4">Get to know us</div>
                        <h2 class="text-center">About Us</h2>
                        <p class="text-center mt-5">Nanji 2010 Company Limited incorporated
                            on 23rd November, 2012 and given certificate of registration
                            number 89688 and Tax Identification Number 116-731-398. The company
                            deals with selling of automobiles. In 2019/20 the company is processing
                            establishment of automobile assembling factory in Dar es salaam, Tanzania.</p>

                        <p class="text-center mt-5">Nanji 2010 Company Limited in joint venture established Tanken Marine Logistics Limited to offer marine transportation and logistics services. The JV Company provide service of transporting and cargo passengers from Mombasa, Zanzibar, Dar es salaam to Comoro Islands. other passenger vessel will operate in Maroni, Fomboni and Anjuan in Comoro islands.</p>

                        <p class="text-center mt-5">Nanji 2010 Company Limited appointed on March, 2018 as Siyahamba Inc. USA Local representative in Burundi, Malawi, Tanzania, Uganda and Zimbabwe with the objective and mandate to filter local request or receive forwarded inquiries from Siyahamba companies for high value suitable projects needs project funding in mentioned countries.</p>

                        <p class="text-center mt-5">The Nanji 2010 Company Limited also engaging in the supplies of building construction materials, industrial raw minerals, automobile/automotive spare parts and electrical insulator for transmission and hot line connectors for different applications.</p>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>