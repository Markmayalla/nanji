<div class="section background-dark padding-top-bottom-smaller over-hide">
		<div class="section z-bigger">		
			<div class="container">
				<div class="row">
					<div class="col-6 col-sm-6 col-md-4 col-lg-2 text-center">
						<div class="amenities">
							<img src="img/icons/1.svg" alt="">
							<p>no smoking</p>
						</div>
					</div>
					<div class="col-6 col-sm-6 col-md-4 col-lg-2 text-center">
						<div class="amenities">
							<img src="img/icons/2.svg" alt="">
							<p>big beds</p>
						</div>
					</div>
					<div class="col-6 col-sm-6 col-md-4 col-lg-2 text-center mt-4 mt-md-0">
						<div class="amenities">
							<img src="img/icons/3.svg" alt="">
							<p>yacht riding</p>
						</div>
					</div>
					<div class="col-6 col-sm-6 col-md-4 col-lg-2 text-center mt-4 mt-lg-0">
						<div class="amenities">
							<img src="img/icons/4.svg" alt="">
							<p>free drinks</p>
						</div>
					</div>
					<div class="col-6 col-sm-6 col-md-4 col-lg-2 text-center mt-4 mt-lg-0">
						<div class="amenities">
							<img src="img/icons/5.svg" alt="">
							<p>swimming pool</p>
						</div>
					</div>
					<div class="col-6 col-sm-6 col-md-4 col-lg-2 text-center mt-4 mt-lg-0">
						<div class="amenities">
							<img src="img/icons/6.svg" alt="">
							<p>room breakfast</p>
						</div>
					</div>
				</div>
			</div>					
		</div>
	</div>