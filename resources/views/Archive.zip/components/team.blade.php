<div class="section padding-top-bottom over-hide">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-8 align-self-center">
					<div class="subtitle with-line text-center mb-4">Executive</div>
					<h3 class="text-center padding-bottom-small">Our Board of Directors</h3>
				</div>

				<div class="section clearfix"></div>
				<div class="col-md-4">
					<div class="services-box restaurant testimonials text-center">
						<img src="img/team/nanji.png" alt="">
                        <h6 class="mt-3">Nanji Masambuli</h5>
                        <small class="mt-3">CEO</small>
						<h5 class="mt-3">
							<a href="#"><i class="fab fa-facebook"></i></a>
							<a href="#"><i class="fab fa-twitter"></i></a>
							<a href="#"><i class="fab fa-instagram"></i></a>
							<a href="#"><i class="fab fa-linkedin"></i></a>
						</h5>
					</div>
				</div>

				<div class="col-md-4 mt-5 mt-md-0">
					<div class="services-box restaurant testimonials text-center">
						<img src="img/team/mahamoud.png" alt="" />
                        <h6 class="mt-3">Mahamoud Kissawaga</h5>
                        <small class="mt-3">Director</small>
						<h5 class="mt-3">
							<a href="#"><i class="fab fa-facebook"></i></a>
							<a href="#"><i class="fab fa-twitter"></i></a>
							<a href="#"><i class="fab fa-instagram"></i></a>
							<a href="#"><i class="fab fa-linkedin"></i></a>
						</h5>
					</div>
				</div>
				
			</div>
		</div>
	</div>