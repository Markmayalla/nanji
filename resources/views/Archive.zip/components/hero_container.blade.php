<div class="section big-55-height over-hide z-bigger">
	
		<div class="parallax parallax-top" style="background-image: url(<?=@$image;?>)"></div>
		<div class="dark-over-pages"></div>
	
		<div class="hero-center-section pages">
			<div class="container">
				<div class="row justify-content-center">
					<div class="col-12 parallax-fade-top">
						<div class="hero-text text-white">{{ $title }}</div>
					</div>
				</div>
			</div>
		</div>
	</div>